#ifndef GRAPHICS_H
#define GRAPHICS_H

#define CANVAS_WIDTH  80
#define CANVAS_HEIGHT 25

/* Drawing Canvas character matrices */
extern char canvas[CANVAS_HEIGHT][CANVAS_WIDTH];
extern int grid_view_enabled;

/* Canvas operations */
void graphics_init_canvas(void);
void graphics_clear_canvas(void);
void graphics_set_pixel(int x, int y, char draw_char);
char graphics_get_pixel(int x, int y);

/* Bresenham Line Drawing */
void graphics_draw_line(int x1, int y1, int x2, int y2, char draw_char);

/* Midpoint Circle Drawing */
void graphics_draw_circle(int xc, int yc, int r, char draw_char, int fill);

/* Midpoint Ellipse Drawing */
void graphics_draw_ellipse(int xc, int yc, int rx, int ry, char draw_char, int fill);

/* Triangle Drawing */
void graphics_draw_triangle(int x1, int y1, int x2, int y2, int x3, int y3, char draw_char, int fill);

/* General Polygon Drawing & Scanline Fill */
void graphics_draw_polygon(const int *xs, const int *ys, int num_points, char draw_char, int fill);
void graphics_scanline_fill_polygon(const int *xs, const int *ys, int num_points, char draw_char);

#endif /* GRAPHICS_H */
