#ifndef FILE_MANAGER_H
#define FILE_MANAGER_H

int file_save_project(const char *filepath);
int file_load_project(const char *filepath);
int file_export_canvas_txt(const char *filepath);
void file_trigger_autosave(void);
void file_trigger_autobackup(void);

#endif /* FILE_MANAGER_H */
