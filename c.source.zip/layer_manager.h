#ifndef LAYER_MANAGER_H
#define LAYER_MANAGER_H

#define MAX_LAYERS 10

typedef struct {
    int id;
    char name[32];
    int is_visible;
    int render_order; /* Lower renders first */
} Layer;

extern Layer layers[MAX_LAYERS];
extern int layer_count;
extern int active_layer_id;

void layer_init_default(void);
int layer_create(const char *name);
int layer_delete(int id);
int layer_set_visibility(int id, int visible);
int layer_is_visible(int id);
int layer_set_render_order(int id, int order);
int layer_get_render_list(int *ids_out); /* Returns count, fills ids_out sorted by render_order */
int layer_find_index(int id);
void layer_move_object(int obj_id, int target_layer_id);

#endif /* LAYER_MANAGER_H */
