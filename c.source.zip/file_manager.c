#define _CRT_SECURE_NO_WARNINGS
#include "file_manager.h"
#include "object_manager.h"
#include "layer_manager.h"
#include "graphics.h"
#include "utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef _WIN32
#include <direct.h>
#else
#include <sys/stat.h>
#endif

int file_save_project(const char *filepath) {
    FILE *f = fopen(filepath, "w");
    if (!f) return 0;
    
    fprintf(f, "VERSION;1.0.0\n");
    
    /* Save layers */
    fprintf(f, "LAYERS_COUNT;%d\n", layer_count);
    for (int i = 0; i < layer_count; i++) {
        Layer *l = &layers[i];
        fprintf(f, "LAY;%d;%s;%d;%d\n", l->id, l->name, l->is_visible, l->render_order);
    }
    
    /* Save objects */
    fprintf(f, "OBJECTS_COUNT;%d\n", object_count);
    for (int i = 0; i < object_count; i++) {
        CanvasObject *o = &object_registry[i];
        fprintf(f, "OBJ;%d;%d;%s;%lld;%d;%d;%d;%d;%c;%d;", 
                o->id, (int)o->type, o->name, (long long)o->creation_time, 
                o->layer, o->is_visible, o->is_locked, o->group_id, o->draw_char, o->is_filled);
                
        switch (o->type) {
            case SHAPE_LINE:
                fprintf(f, "%d;%d;%d;%d\n", 
                        o->params.line.p1.x, o->params.line.p1.y,
                        o->params.line.p2.x, o->params.line.p2.y);
                break;
            case SHAPE_RECTANGLE:
                fprintf(f, "%d;%d;%d;%d\n", 
                        o->params.rect.top_left.x, o->params.rect.top_left.y,
                        o->params.rect.width, o->params.rect.height);
                break;
            case SHAPE_CIRCLE:
                fprintf(f, "%d;%d;%d\n", 
                        o->params.circle.center.x, o->params.circle.center.y,
                        o->params.circle.radius);
                break;
            case SHAPE_TRIANGLE:
                fprintf(f, "%d;%d;%d;%d;%d;%d\n", 
                        o->params.triangle.v1.x, o->params.triangle.v1.y,
                        o->params.triangle.v2.x, o->params.triangle.v2.y,
                        o->params.triangle.v3.x, o->params.triangle.v3.y);
                break;
            case SHAPE_ELLIPSE:
                fprintf(f, "%d;%d;%d;%d\n", 
                        o->params.ellipse.center.x, o->params.ellipse.center.y,
                        o->params.ellipse.rx, o->params.ellipse.ry);
                break;
            case SHAPE_POLYGON: {
                int n = o->params.polygon.num_vertices;
                fprintf(f, "%d", n);
                for (int k = 0; k < n; k++) {
                    fprintf(f, ";%d;%d", o->params.polygon.vertices[k].x, o->params.polygon.vertices[k].y);
                }
                fprintf(f, "\n");
                break;
            }
        }
    }
    
    fclose(f);
    return 1;
}

int file_load_project(const char *filepath) {
    FILE *f = fopen(filepath, "r");
    if (!f) return 0;
    
    char line[1024];
    int l_count = 0;
    int o_count = 0;
    
    /* Clear active registries */
    object_count = 0;
    layer_count = 0;
    selected_object_id = -1;
    obj_history_clear();

    while (fgets(line, sizeof(line), f)) {
        /* Remove newline */
        line[strcspn(line, "\r\n")] = '\0';
        
        char *token = strtok(line, ";");
        if (!token) continue;
        
        if (strcmp(token, "LAY") == 0) {
            if (layer_count >= MAX_LAYERS) continue;
            
            Layer *l = &layers[layer_count++];
            l->id = atoi(strtok(NULL, ";"));
            strncpy(l->name, strtok(NULL, ";"), sizeof(l->name) - 1);
            l->name[sizeof(l->name) - 1] = '\0';
            l->is_visible = atoi(strtok(NULL, ";"));
            l->render_order = atoi(strtok(NULL, ";"));
        }
        else if (strcmp(token, "OBJ") == 0) {
            if (object_count >= MAX_OBJECTS) continue;
            
            CanvasObject *o = &object_registry[object_count++];
            o->id = atoi(strtok(NULL, ";"));
            o->type = (ShapeType)atoi(strtok(NULL, ";"));
            strncpy(o->name, strtok(NULL, ";"), sizeof(o->name) - 1);
            o->name[sizeof(o->name) - 1] = '\0';
            o->creation_time = (time_t)atoll(strtok(NULL, ";"));
            o->layer = atoi(strtok(NULL, ";"));
            o->is_visible = atoi(strtok(NULL, ";"));
            o->is_locked = atoi(strtok(NULL, ";"));
            o->group_id = atoi(strtok(NULL, ";"));
            
            char *char_tok = strtok(NULL, ";");
            o->draw_char = char_tok ? char_tok[0] : '*';
            o->is_filled = atoi(strtok(NULL, ";"));
            
            switch (o->type) {
                case SHAPE_LINE:
                    o->params.line.p1.x = atoi(strtok(NULL, ";"));
                    o->params.line.p1.y = atoi(strtok(NULL, ";"));
                    o->params.line.p2.x = atoi(strtok(NULL, ";"));
                    o->params.line.p2.y = atoi(strtok(NULL, ";"));
                    break;
                case SHAPE_RECTANGLE:
                    o->params.rect.top_left.x = atoi(strtok(NULL, ";"));
                    o->params.rect.top_left.y = atoi(strtok(NULL, ";"));
                    o->params.rect.width = atoi(strtok(NULL, ";"));
                    o->params.rect.height = atoi(strtok(NULL, ";"));
                    break;
                case SHAPE_CIRCLE:
                    o->params.circle.center.x = atoi(strtok(NULL, ";"));
                    o->params.circle.center.y = atoi(strtok(NULL, ";"));
                    o->params.circle.radius = atoi(strtok(NULL, ";"));
                    break;
                case SHAPE_TRIANGLE:
                    o->params.triangle.v1.x = atoi(strtok(NULL, ";"));
                    o->params.triangle.v1.y = atoi(strtok(NULL, ";"));
                    o->params.triangle.v2.x = atoi(strtok(NULL, ";"));
                    o->params.triangle.v2.y = atoi(strtok(NULL, ";"));
                    o->params.triangle.v3.x = atoi(strtok(NULL, ";"));
                    o->params.triangle.v3.y = atoi(strtok(NULL, ";"));
                    break;
                case SHAPE_ELLIPSE:
                    o->params.ellipse.center.x = atoi(strtok(NULL, ";"));
                    o->params.ellipse.center.y = atoi(strtok(NULL, ";"));
                    o->params.ellipse.rx = atoi(strtok(NULL, ";"));
                    o->params.ellipse.ry = atoi(strtok(NULL, ";"));
                    break;
                case SHAPE_POLYGON: {
                    int n = atoi(strtok(NULL, ";"));
                    o->params.polygon.num_vertices = n;
                    for (int k = 0; k < n; k++) {
                        o->params.polygon.vertices[k].x = atoi(strtok(NULL, ";"));
                        o->params.polygon.vertices[k].y = atoi(strtok(NULL, ";"));
                    }
                    break;
                }
            }
        }
    }
    
    fclose(f);
    
    /* Make sure layer default variables are clean if file didn't specify layers */
    if (layer_count == 0) {
        layer_init_default();
    }
    
    return 1;
}

int file_export_canvas_txt(const char *filepath) {
    /* Regenerate composite buffer */
    compositor_render();
    
    FILE *f = fopen(filepath, "w");
    if (!f) return 0;
    
    for (int y = 0; y < CANVAS_HEIGHT; y++) {
        for (int x = 0; x < CANVAS_WIDTH; x++) {
            fputc(canvas[y][x], f);
        }
        fputc('\n', f);
    }
    
    fclose(f);
    return 1;
}

void file_trigger_autosave(void) {
    /* Ensure data directory exists */
#ifdef _WIN32
    _mkdir("data");
#else
    mkdir("data", 0777);
#endif
    file_save_project("data/autosave.aststudio");
}

void file_trigger_autobackup(void) {
#ifdef _WIN32
    _mkdir("data");
#else
    mkdir("data", 0777);
#endif

    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    char filepath[128];
    
    if (t) {
        sprintf(filepath, "data/backup_%04d%02d%02d_%02d%02d%02d.aststudio",
                t->tm_year + 1900, t->tm_mon + 1, t->tm_mday,
                t->tm_hour, t->tm_min, t->tm_sec);
    } else {
        sprintf(filepath, "data/backup_%lld.aststudio", (long long)now);
    }
    
    file_save_project(filepath);
}
