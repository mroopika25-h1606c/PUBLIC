#define _CRT_SECURE_NO_WARNINGS
#include "utils.h"

#ifdef USE_NCURSES
#include <curses.h>
#else
#ifdef _WIN32
#include <windows.h>
#include <conio.h>
#else
#include <unistd.h>
#include <termios.h>
#include <sys/select.h>
#endif
#endif

/* Global state to check initialization */
static int term_initialized = 0;

#ifndef USE_NCURSES
#ifndef _WIN32
/* POSIX implementation of kbhit/getch for fallback ANSI mode */
static struct termios orig_termios;

static void disable_raw_mode(void) {
    tcsetattr(STDIN_FILENO, TCSAFLUSH, &orig_termios);
}

static void enable_raw_mode(void) {
    tcgetattr(STDIN_FILENO, &orig_termios);
    atexit(disable_raw_mode);
    struct termios raw = orig_termios;
    raw.c_lflag &= ~(ECHO | ICANON | ISIG | IEXTEN);
    raw.c_iflag &= ~(BRKINT | ICRNL | INPCK | ISTRIP | IXON);
    raw.c_cflag |= (CS8);
    raw.c_cc[VMIN] = 0;
    raw.c_cc[VTIME] = 1;
    tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw);
}

static int posix_kbhit(void) {
    struct timeval tv = {0L, 0L};
    fd_set fds;
    FD_ZERO(&fds);
    FD_SET(STDIN_FILENO, &fds);
    return select(STDIN_FILENO + 1, &fds, NULL, NULL, &tv) > 0;
}

static int posix_getch(void) {
    char ch = 0;
    if (read(STDIN_FILENO, &ch, 1) < 0) return 0;
    return ch;
}
#endif
#endif

void term_init(void) {
    if (term_initialized) return;

#ifdef USE_NCURSES
    initscr();
    raw();
    noecho();
    keypad(stdscr, TRUE);
    nodelay(stdscr, FALSE);
    start_color();
    
    /* Initialize color pairs */
    /* Ncurses colors:
       COLOR_BLACK   0
       COLOR_RED     1
       COLOR_GREEN   2
       COLOR_YELLOW  3
       COLOR_BLUE    4
       COLOR_MAGENTA 5
       COLOR_CYAN    6
       COLOR_WHITE   7
    */
    for (int fg = 0; fg < 8; fg++) {
        for (int bg = 0; bg < 8; bg++) {
            init_pair(fg * 8 + bg + 1, fg, bg);
        }
    }
#else
#ifdef _WIN32
    /* Enable Virtual Terminal Processing for Windows CMD */
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    if (hOut != INVALID_HANDLE_VALUE) {
        DWORD dwMode = 0;
        if (GetConsoleMode(hOut, &dwMode)) {
            dwMode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING;
            SetConsoleMode(hOut, dwMode);
        }
    }
    SetConsoleOutputCP(CP_UTF8);
#else
    enable_raw_mode();
#endif
#endif

    term_initialized = 1;
}

void term_shutdown(void) {
    if (!term_initialized) return;

#ifdef USE_NCURSES
    endwin();
#else
#ifdef _WIN32
    /* Reset console colors */
    printf("\033[0m");
#else
    disable_raw_mode();
    printf("\033[0m");
#endif
#endif

    term_initialized = 0;
}

void term_clear(void) {
#ifdef USE_NCURSES
    clear();
#else
    printf("\033[2J\033[H");
#endif
}

void term_move_cursor(int y, int x) {
#ifdef USE_NCURSES
    move(y, x);
#else
    /* ANSI coordinates are 1-based */
    printf("\033[%d;%dH", y + 1, x + 1);
#endif
}

void term_set_color(TermColor fg, TermColor bg) {
#ifdef USE_NCURSES
    int n_fg = COLOR_WHITE;
    int n_bg = COLOR_BLACK;

    switch (fg) {
        case TERM_COLOR_BLACK:   n_fg = COLOR_BLACK; break;
        case TERM_COLOR_RED:     n_fg = COLOR_RED; break;
        case TERM_COLOR_GREEN:   n_fg = COLOR_GREEN; break;
        case TERM_COLOR_YELLOW:  n_fg = COLOR_YELLOW; break;
        case TERM_COLOR_BLUE:    n_fg = COLOR_BLUE; break;
        case TERM_COLOR_MAGENTA: n_fg = COLOR_MAGENTA; break;
        case TERM_COLOR_CYAN:    n_fg = COLOR_CYAN; break;
        case TERM_COLOR_WHITE:   n_fg = COLOR_WHITE; break;
        default:                 n_fg = COLOR_WHITE; break;
    }

    switch (bg) {
        case TERM_COLOR_BLACK:   n_bg = COLOR_BLACK; break;
        case TERM_COLOR_RED:     n_bg = COLOR_RED; break;
        case TERM_COLOR_GREEN:   n_bg = COLOR_GREEN; break;
        case TERM_COLOR_YELLOW:  n_bg = COLOR_YELLOW; break;
        case TERM_COLOR_BLUE:    n_bg = COLOR_BLUE; break;
        case TERM_COLOR_MAGENTA: n_bg = COLOR_MAGENTA; break;
        case TERM_COLOR_CYAN:    n_bg = COLOR_CYAN; break;
        case TERM_COLOR_WHITE:   n_bg = COLOR_WHITE; break;
        default:                 n_bg = COLOR_BLACK; break;
    }

    int pair = n_fg * 8 + n_bg + 1;
    attron(COLOR_PAIR(pair));
#else
    int ansi_fg = 39; // default
    int ansi_bg = 49; // default

    switch (fg) {
        case TERM_COLOR_BLACK:   ansi_fg = 30; break;
        case TERM_COLOR_RED:     ansi_fg = 31; break;
        case TERM_COLOR_GREEN:   ansi_fg = 32; break;
        case TERM_COLOR_YELLOW:  ansi_fg = 33; break;
        case TERM_COLOR_BLUE:    ansi_fg = 34; break;
        case TERM_COLOR_MAGENTA: ansi_fg = 35; break;
        case TERM_COLOR_CYAN:    ansi_fg = 36; break;
        case TERM_COLOR_WHITE:   ansi_fg = 37; break;
        default:                 ansi_fg = 39; break;
    }

    switch (bg) {
        case TERM_COLOR_BLACK:   ansi_bg = 40; break;
        case TERM_COLOR_RED:     ansi_bg = 41; break;
        case TERM_COLOR_GREEN:   ansi_bg = 42; break;
        case TERM_COLOR_YELLOW:  ansi_bg = 43; break;
        case TERM_COLOR_BLUE:    ansi_bg = 44; break;
        case TERM_COLOR_MAGENTA: ansi_bg = 45; break;
        case TERM_COLOR_CYAN:    ansi_bg = 46; break;
        case TERM_COLOR_WHITE:   ansi_bg = 47; break;
        default:                 ansi_bg = 49; break;
    }

    printf("\033[%d;%dm", ansi_fg, ansi_bg);
#endif
}

void term_reset_color(void) {
#ifdef USE_NCURSES
    /* Turn off all color attributes */
    for (int fg = 0; fg < 8; fg++) {
        for (int bg = 0; bg < 8; bg++) {
            attroff(COLOR_PAIR(fg * 8 + bg + 1));
        }
    }
#else
    printf("\033[0m");
#endif
}

int term_get_key(void) {
#ifdef USE_NCURSES
    int ch = getch();
    switch (ch) {
        case 27:        return KEY_ESC;
        case 10:
        case KEY_ENTER: return KEY_ENTER;
        case KEY_BACKSPACE:
        case 127:
        case 8:         return KEY_BACKSPACE;
        case '\t':      return KEY_TAB;
        case KEY_UP:    return KEY_UP_ARROW;
        case KEY_DOWN:  return KEY_DOWN_ARROW;
        case KEY_LEFT:  return KEY_LEFT_ARROW;
        case KEY_RIGHT: return KEY_RIGHT_ARROW;
        case KEY_DC:    return KEY_DELETE_KEY;
        default:        return ch;
    }
#else
#ifdef _WIN32
    if (!_kbhit()) return 0;
    int ch = _getch();
    if (ch == 0 || ch == 224) {
        int next_ch = _getch();
        switch (next_ch) {
            case 72: return KEY_UP_ARROW;
            case 80: return KEY_DOWN_ARROW;
            case 75: return KEY_LEFT_ARROW;
            case 77: return KEY_RIGHT_ARROW;
            case 83: return KEY_DELETE_KEY;
            default: return 0;
        }
    }
    if (ch == 13) return KEY_ENTER;
    if (ch == 8) return KEY_BACKSPACE;
    if (ch == 9) return KEY_TAB;
    if (ch == 27) return KEY_ESC;
    return ch;
#else
    if (!posix_kbhit()) return 0;
    int ch = posix_getch();
    if (ch == 27) {
        /* Check if it's an arrow key escape sequence */
        /* Arrow keys are ESC [ A, B, C, D */
        int ch2 = posix_getch();
        if (ch2 == '[') {
            int ch3 = posix_getch();
            switch (ch3) {
                case 'A': return KEY_UP_ARROW;
                case 'B': return KEY_DOWN_ARROW;
                case 'C': return KEY_RIGHT_ARROW;
                case 'D': return KEY_LEFT_ARROW;
                case '3': {
                    int ch4 = posix_getch(); // read '~' for delete
                    if (ch4 == '~') return KEY_DELETE_KEY;
                }
                default: return KEY_ESC;
            }
        }
        return KEY_ESC;
    }
    if (ch == 10) return KEY_ENTER;
    if (ch == 127 || ch == 8) return KEY_BACKSPACE;
    if (ch == 9) return KEY_TAB;
    return ch;
#endif
#endif
}

void term_sleep(int ms) {
#ifdef _WIN32
    Sleep(ms);
#else
    usleep(ms * 1000);
#endif
}

void term_flush(void) {
#ifdef USE_NCURSES
    refresh();
#else
    fflush(stdout);
#endif
}

void term_draw_box(int y, int x, int height, int width, const char *title) {
    /* Draw borders */
    term_set_color(TERM_COLOR_CYAN, TERM_COLOR_BLACK);
    
    // Top border
    term_move_cursor(y, x);
    printf("┌");
    for (int i = 1; i < width - 1; i++) printf("─");
    printf("┐");

    // Middle sections
    for (int i = 1; i < height - 1; i++) {
        term_move_cursor(y + i, x);
        printf("│");
        term_move_cursor(y + i, x + width - 1);
        printf("│");
    }

    // Bottom border
    term_move_cursor(y + height - 1, x);
    printf("└");
    for (int i = 1; i < width - 1; i++) printf("─");
    printf("┘");

    /* Draw title if present */
    if (title && strlen(title) > 0) {
        int title_len = (int)strlen(title);
        int start_x = x + (width - title_len - 2) / 2;
        if (start_x < x + 1) start_x = x + 1;
        term_move_cursor(y, start_x);
        term_set_color(TERM_COLOR_YELLOW, TERM_COLOR_BLACK);
        printf(" %s ", title);
    }
    term_reset_color();
}

void term_draw_horizontal_line(int y, int x, int length) {
    term_move_cursor(y, x);
    for (int i = 0; i < length; i++) {
        printf("─");
    }
}

void term_draw_status_bar(const char *left_text, const char *right_text) {
    // Standard status bar at line 29 on a 30-line display
    int term_h = 30; // assume default height
    int term_w = 110; // assume default width
    
    term_move_cursor(term_h - 1, 0);
    term_set_color(TERM_COLOR_BLACK, TERM_COLOR_WHITE);
    
    // Clear status bar line
    for (int i = 0; i < term_w; i++) printf(" ");
    
    // Print left text
    term_move_cursor(term_h - 1, 1);
    printf("%s", left_text);
    
    // Print right text right-aligned
    if (right_text) {
        int len = (int)strlen(right_text);
        term_move_cursor(term_h - 1, term_w - len - 1);
        printf("%s", right_text);
    }
    term_reset_color();
}

void term_splash_screen(void) {
    term_clear();
    term_set_color(TERM_COLOR_CYAN, TERM_COLOR_BLACK);
    
    int start_y = 6;
    int start_x = 15;
    
    term_move_cursor(start_y++, start_x);
    printf("█████╗ ███████╗ ██████╗██████╗    ██████╗ ██████╗  ██████╗ ");
    term_move_cursor(start_y++, start_x);
    printf("██╔══██╗██╔════╝██╔════╝╚══██╔══╝    ██╔══██╗██╔══██╗██╔═══██╗");
    term_move_cursor(start_y++, start_x);
    printf("███████║███████╗██║         ██║       ██████╔╝██████╔╝██║   ██║");
    term_move_cursor(start_y++, start_x);
    printf("██╔══██║╚════██║██║         ██║       ██╔═══╝ ██╔══██╗██║   ██║");
    term_move_cursor(start_y++, start_x);
    printf("██║  ██║███████║╚██████╗    ██║       ██║     ██║  ██║╚██████╔╝");
    term_move_cursor(start_y++, start_x);
    printf("╚═╝  ╚═╝╚══════╝ ╚═════╝    ╚═╝       ╚═╝     ╚═╝  ╚═╝ ╚═════╝ ");
    
    term_move_cursor(start_y + 1, start_x + 10);
    term_set_color(TERM_COLOR_YELLOW, TERM_COLOR_BLACK);
    printf("--- PROFESSIONAL ASCII GRAPHICS STUDIO PRO v1.0.0 ---");
    
    term_move_cursor(start_y + 3, start_x + 8);
    term_set_color(TERM_COLOR_GREEN, TERM_COLOR_BLACK);
    printf("Advanced C Programming project. Double-Engine Terminal UI.");
    
    term_move_cursor(start_y + 5, start_x + 16);
    term_set_color(TERM_COLOR_WHITE, TERM_COLOR_BLACK);
    printf("Initializing Object Registries...");
    term_flush();
    term_sleep(600);

    term_move_cursor(start_y + 5, start_x + 16);
    printf("Loading Compositor Modules...   ");
    term_flush();
    term_sleep(600);

    term_move_cursor(start_y + 5, start_x + 16);
    printf("Starting Graphical Interface... ");
    term_flush();
    term_sleep(600);
}

void term_loading_animation(const char *message) {
    int start_y = 13;
    int start_x = 35;
    
    term_move_cursor(start_y, start_x);
    term_set_color(TERM_COLOR_MAGENTA, TERM_COLOR_BLACK);
    printf("%s", message);
    
    char frames[] = {'|', '/', '-', '\\'};
    for (int i = 0; i < 12; i++) {
        term_move_cursor(start_y, start_x + (int)strlen(message) + 1);
        printf("[%c]", frames[i % 4]);
        term_flush();
        term_sleep(80);
    }
    term_reset_color();
}

void term_dialog_message(const char *title, const char *msg) {
    int box_w = 50;
    int box_h = 8;
    int start_y = 10;
    int start_x = 30;

    term_draw_box(start_y, start_x, box_h, box_w, title);
    
    term_move_cursor(start_y + 2, start_x + 4);
    term_set_color(TERM_COLOR_WHITE, TERM_COLOR_BLACK);
    printf("%s", msg);

    term_move_cursor(start_y + 5, start_x + (box_w - 20) / 2);
    term_set_color(TERM_COLOR_YELLOW, TERM_COLOR_BLACK);
    printf("Press [ENTER] to close");
    term_flush();

    while (1) {
        int k = term_get_key();
        if (k == KEY_ENTER || k == KEY_ESC || k == ' ' || k == '\n') {
            break;
        }
        term_sleep(30);
    }
}

int term_dialog_input(const char *title, const char *prompt, char *buffer, int max_len) {
    int box_w = 60;
    int box_h = 8;
    int start_y = 10;
    int start_x = 25;

    term_draw_box(start_y, start_x, box_h, box_w, title);
    
    term_move_cursor(start_y + 2, start_x + 4);
    term_set_color(TERM_COLOR_WHITE, TERM_COLOR_BLACK);
    printf("%s", prompt);

    term_move_cursor(start_y + 4, start_x + 4);
    term_set_color(TERM_COLOR_GREEN, TERM_COLOR_BLACK);
    printf("> ");
    term_flush();

    int idx = 0;
    buffer[0] = '\0';

#ifdef USE_NCURSES
    echo();
    nodelay(stdscr, FALSE);
#endif

    while (idx < max_len - 1) {
        int k = term_get_key();
        if (k == 0) {
            term_sleep(30);
            continue;
        }
        if (k == KEY_ENTER || k == '\n' || k == '\r') {
            break;
        }
        if (k == KEY_ESC) {
            buffer[0] = '\0';
            idx = -1;
            break;
        }
        if (k == KEY_BACKSPACE) {
            if (idx > 0) {
                idx--;
                buffer[idx] = '\0';
                term_move_cursor(start_y + 4, start_x + 6 + idx);
                printf(" \b");
                term_flush();
            }
        } else if (k >= 32 && k <= 126) {
            buffer[idx++] = (char)k;
            buffer[idx] = '\0';
            printf("%c", (char)k);
            term_flush();
        }
    }

#ifdef USE_NCURSES
    noecho();
#endif

    term_reset_color();
    return idx;
}

int term_dialog_confirm(const char *title, const char *prompt) {
    int box_w = 50;
    int box_h = 8;
    int start_y = 10;
    int start_x = 30;

    term_draw_box(start_y, start_x, box_h, box_w, title);
    
    term_move_cursor(start_y + 2, start_x + 4);
    term_set_color(TERM_COLOR_WHITE, TERM_COLOR_BLACK);
    printf("%s", prompt);

    term_move_cursor(start_y + 5, start_x + 12);
    term_set_color(TERM_COLOR_YELLOW, TERM_COLOR_BLACK);
    printf("[Y] Yes    [N] No (or ESC)");
    term_flush();

    while (1) {
        int k = term_get_key();
        if (k == 'y' || k == 'Y') {
            return 1;
        }
        if (k == 'n' || k == 'N' || k == KEY_ESC) {
            return 0;
        }
        term_sleep(30);
    }
}

int parse_int(const char *str, int *val) {
    char *endptr;
    long l_val = strtol(str, &endptr, 10);
    if (endptr == str || *endptr != '\0') {
        return 0; // failure
    }
    *val = (int)l_val;
    return 1; // success
}

int validate_range(int val, int min, int max) {
    return (val >= min && val <= max);
}

void format_timestamp(time_t ts, char *buffer, int max_len) {
    struct tm *tm_info = localtime(&ts);
    if (tm_info) {
        strftime(buffer, max_len, "%Y-%m-%d %H:%M:%S", tm_info);
    } else {
        strncpy(buffer, "N/A", max_len);
    }
}
