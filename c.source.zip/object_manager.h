#ifndef OBJECT_MANAGER_H
#define OBJECT_MANAGER_H

#include "graphics.h"
#include <time.h>

typedef enum {
    SHAPE_LINE,
    SHAPE_RECTANGLE,
    SHAPE_CIRCLE,
    SHAPE_TRIANGLE,
    SHAPE_ELLIPSE,
    SHAPE_POLYGON
} ShapeType;

typedef struct {
    int x;
    int y;
} ObjPoint;

typedef struct {
    ObjPoint p1;
    ObjPoint p2;
} LineParams;

typedef struct {
    ObjPoint top_left;
    int width;
    int height;
} RectParams;

typedef struct {
    ObjPoint center;
    int radius;
} CircleParams;

typedef struct {
    ObjPoint v1;
    ObjPoint v2;
    ObjPoint v3;
} TriangleParams;

typedef struct {
    ObjPoint center;
    int rx;
    int ry;
} EllipseParams;

#define MAX_POLY_POINTS 16
typedef struct {
    ObjPoint vertices[MAX_POLY_POINTS];
    int num_vertices;
} PolyParams;

typedef union {
    LineParams line;
    RectParams rect;
    CircleParams circle;
    TriangleParams triangle;
    EllipseParams ellipse;
    PolyParams polygon;
} ShapeParams;

typedef struct {
    int id;
    ShapeType type;
    char name[32];
    ShapeParams params;
    time_t creation_time;
    int layer;
    int is_visible;
    int is_locked;
    int group_id;
    char draw_char;
    int is_filled;
} CanvasObject;

#define MAX_OBJECTS 1000
extern CanvasObject object_registry[MAX_OBJECTS];
extern int object_count;

/* Selection Clipboard */
extern CanvasObject object_clipboard;
extern int clipboard_has_object;

/* Selection State */
extern int selected_object_id;

/* Undo/Redo System */
#define MAX_UNDO_STATES 30
void obj_history_save(void);
int obj_history_undo(void);
int obj_history_redo(void);
void obj_history_clear(void);

/* CRUD Operations */
int obj_create_line(int x1, int y1, int x2, int y2, char draw_char, int layer);
int obj_create_rectangle(int x, int y, int w, int h, char draw_char, int layer, int filled);
int obj_create_circle(int xc, int yc, int r, char draw_char, int layer, int filled);
int obj_create_triangle(int x1, int y1, int x2, int y2, int x3, int y3, char draw_char, int layer, int filled);
int obj_create_ellipse(int xc, int yc, int rx, int ry, char draw_char, int layer, int filled);
int obj_create_polygon(const int *xs, const int *ys, int num_points, char draw_char, int layer, int filled);

int obj_delete(int id);
int obj_delete_multiple(const int *ids, int count);
void obj_clear_all(void);

CanvasObject* obj_find_by_id(int id);
int obj_find_all_in_group(int group_id, int *ids_out, int max_out);

/* Transformations */
void obj_translate(CanvasObject *obj, int dx, int dy);
void obj_resize(CanvasObject *obj, int dp1, int dp2);
void obj_scale(CanvasObject *obj, double scale_factor);
void obj_rotate_triangle(CanvasObject *obj, double angle_deg);
void obj_mirror_horizontal(CanvasObject *obj);
void obj_mirror_vertical(CanvasObject *obj);

/* Editor Tools */
int obj_copy(int id);
int obj_paste(int layer);
int obj_duplicate(int id);
int obj_group(const int *ids, int count);
int obj_ungroup(int group_id);

/* Rendering Compositor */
void compositor_render(void);

#endif /* OBJECT_MANAGER_H */
