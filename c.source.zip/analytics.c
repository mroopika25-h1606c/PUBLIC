#include "analytics.h"
#include "object_manager.h"
#include "layer_manager.h"
#include "graphics.h"
#include <string.h>

void analytics_get_dashboard(AnalyticsDashboard *dash) {
    if (!dash) return;
    
    dash->total_objects = object_count;
    dash->total_layers = layer_count;
    
    /* Calculate canvas utilization */
    int active_pixels = 0;
    for (int y = 0; y < CANVAS_HEIGHT; y++) {
        for (int x = 0; x < CANVAS_WIDTH; x++) {
            if (canvas[y][x] != '_') {
                active_pixels++;
            }
        }
    }
    dash->canvas_utilization = ((double)active_pixels / (CANVAS_WIDTH * CANVAS_HEIGHT)) * 100.0;
    
    /* Calculate most used shape */
    int counts[6] = {0}; /* Indexes matching ShapeType */
    for (int i = 0; i < object_count; i++) {
        counts[(int)object_registry[i].type]++;
    }
    
    int max_idx = 0;
    int max_val = 0;
    for (int i = 0; i < 6; i++) {
        if (counts[i] > max_val) {
            max_val = counts[i];
            max_idx = i;
        }
    }
    
    if (max_val == 0) {
        strcpy(dash->most_used_shape, "None");
    } else {
        switch ((ShapeType)max_idx) {
            case SHAPE_LINE:      strcpy(dash->most_used_shape, "Line"); break;
            case SHAPE_RECTANGLE: strcpy(dash->most_used_shape, "Rectangle"); break;
            case SHAPE_CIRCLE:    strcpy(dash->most_used_shape, "Circle"); break;
            case SHAPE_TRIANGLE:  strcpy(dash->most_used_shape, "Triangle"); break;
            case SHAPE_ELLIPSE:   strcpy(dash->most_used_shape, "Ellipse"); break;
            case SHAPE_POLYGON:   strcpy(dash->most_used_shape, "Polygon"); break;
            default:              strcpy(dash->most_used_shape, "Unknown"); break;
        }
    }
    
    /* Calculate drawing complexity score */
    int complexity = 0;
    for (int i = 0; i < object_count; i++) {
        CanvasObject *o = &object_registry[i];
        int shape_score = 0;
        
        switch (o->type) {
            case SHAPE_LINE:      shape_score = 10; break;
            case SHAPE_RECTANGLE: shape_score = 15; break;
            case SHAPE_CIRCLE:    shape_score = 20; break;
            case SHAPE_TRIANGLE:  shape_score = 20; break;
            case SHAPE_ELLIPSE:   shape_score = 25; break;
            case SHAPE_POLYGON:
                shape_score = 10 * o->params.polygon.num_vertices;
                break;
        }
        
        if (o->is_filled) {
            shape_score = (int)(shape_score * 1.5);
        }
        
        complexity += shape_score;
    }
    dash->complexity_score = complexity;
    
    /* Estimate active memory footprint (in bytes) */
    /* Accounts for:
       - active object structures
       - active layers
       - composited canvas matrix
    */
    size_t active_bytes = 0;
    active_bytes += sizeof(CanvasObject) * object_count;
    active_bytes += sizeof(Layer) * layer_count;
    active_bytes += sizeof(canvas);
    
    /* Add static memory buffers */
    size_t static_allocated = 0;
    static_allocated += sizeof(object_registry);
    static_allocated += sizeof(layers);
    
    /* We report active heap/stack usage + registry limit */
    dash->memory_bytes = active_bytes + sizeof(canvas);
}
