#ifndef UTILS_H
#define UTILS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/* Unified Keyboard Codes */
#define KEY_ESC          27
#define KEY_ENTER        13
#define KEY_BACKSPACE    8
#define KEY_TAB          9
#define KEY_UP_ARROW     1001
#define KEY_DOWN_ARROW   1002
#define KEY_LEFT_ARROW   1003
#define KEY_RIGHT_ARROW  1004
#define KEY_DELETE_KEY   1005

/* Unified Colors */
typedef enum {
    TERM_COLOR_DEFAULT,
    TERM_COLOR_BLACK,
    TERM_COLOR_RED,
    TERM_COLOR_GREEN,
    TERM_COLOR_YELLOW,
    TERM_COLOR_BLUE,
    TERM_COLOR_MAGENTA,
    TERM_COLOR_CYAN,
    TERM_COLOR_WHITE
} TermColor;

/* Terminal Functions */
void term_init(void);
void term_shutdown(void);
void term_clear(void);
void term_move_cursor(int y, int x);
void term_set_color(TermColor fg, TermColor bg);
void term_reset_color(void);
int term_get_key(void);
void term_sleep(int ms);
void term_flush(void);

/* UI Widgets & Rendering Helpers */
void term_draw_box(int y, int x, int height, int width, const char *title);
void term_draw_horizontal_line(int y, int x, int length);
void term_draw_status_bar(const char *left_text, const char *right_text);
void term_splash_screen(void);
void term_loading_animation(const char *message);
void term_dialog_message(const char *title, const char *msg);
int term_dialog_input(const char *title, const char *prompt, char *buffer, int max_len);
int term_dialog_confirm(const char *title, const char *prompt);

/* Input Validation & Helpers */
int parse_int(const char *str, int *val);
int validate_range(int val, int min, int max);
void format_timestamp(time_t ts, char *buffer, int max_len);

#endif /* UTILS_H */
