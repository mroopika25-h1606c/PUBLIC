#define _CRT_SECURE_NO_WARNINGS
#include "layer_manager.h"
#include "object_manager.h"
#include <string.h>
#include <stdio.h>

Layer layers[MAX_LAYERS];
int layer_count = 0;
int active_layer_id = 0;
static int next_layer_id = 0;

void layer_init_default(void) {
    layer_count = 0;
    next_layer_id = 0;
    
    /* Create three default layers */
    layer_create("Base Layer"); /* ID 0 */
    layer_create("Layer 1");    /* ID 1 */
    layer_create("Layer 2");    /* ID 2 */
    
    active_layer_id = 0;
}

int layer_create(const char *name) {
    if (layer_count >= MAX_LAYERS) return -1;
    
    int new_id = next_layer_id++;
    Layer *l = &layers[layer_count++];
    l->id = new_id;
    
    if (name && strlen(name) > 0) {
        strncpy(l->name, name, sizeof(l->name) - 1);
        l->name[sizeof(l->name) - 1] = '\0';
    } else {
        sprintf(l->name, "Layer %d", new_id);
    }
    
    l->is_visible = 1;
    l->render_order = layer_count - 1;
    
    return new_id;
}

int layer_delete(int id) {
    if (id == 0) return 0; /* Base layer cannot be deleted */
    
    int idx = layer_find_index(id);
    if (idx < 0) return 0;
    
    /* Move objects on this layer to default Layer 0 */
    for (int i = 0; i < object_count; i++) {
        if (object_registry[i].layer == id) {
            object_registry[i].layer = 0;
        }
    }
    
    /* Shift layers left */
    for (int i = idx; i < layer_count - 1; i++) {
        layers[i] = layers[i + 1];
    }
    layer_count--;
    
    /* Update active layer if it was deleted */
    if (active_layer_id == id) {
        active_layer_id = 0;
    }
    
    return 1;
}

int layer_set_visibility(int id, int visible) {
    int idx = layer_find_index(id);
    if (idx < 0) return 0;
    layers[idx].is_visible = visible;
    return 1;
}

int layer_is_visible(int id) {
    int idx = layer_find_index(id);
    if (idx < 0) return 0;
    return layers[idx].is_visible;
}

int layer_set_render_order(int id, int order) {
    int idx = layer_find_index(id);
    if (idx < 0) return 0;
    layers[idx].render_order = order;
    return 1;
}

int layer_get_render_list(int *ids_out) {
    /* Copy IDs */
    int sorted_indices[MAX_LAYERS];
    for (int i = 0; i < layer_count; i++) {
        sorted_indices[i] = i;
    }
    
    /* Sort indices by render_order */
    for (int i = 0; i < layer_count - 1; i++) {
        for (int j = 0; j < layer_count - i - 1; j++) {
            int idx1 = sorted_indices[j];
            int idx2 = sorted_indices[j + 1];
            if (layers[idx1].render_order > layers[idx2].render_order) {
                int temp = sorted_indices[j];
                sorted_indices[j] = sorted_indices[j + 1];
                sorted_indices[j + 1] = temp;
            }
        }
    }
    
    /* Output IDs in sorted order */
    for (int i = 0; i < layer_count; i++) {
        ids_out[i] = layers[sorted_indices[i]].id;
    }
    
    return layer_count;
}

int layer_find_index(int id) {
    for (int i = 0; i < layer_count; i++) {
        if (layers[i].id == id) {
            return i;
        }
    }
    return -1;
}

void layer_move_object(int obj_id, int target_layer_id) {
    CanvasObject *obj = obj_find_by_id(obj_id);
    if (obj && !obj->is_locked) {
        /* Verify target layer exists */
        if (layer_find_index(target_layer_id) >= 0) {
            obj->layer = target_layer_id;
        }
    }
}
