#ifndef ANALYTICS_H
#define ANALYTICS_H

#include <stddef.h>

typedef struct {
    int total_objects;
    int total_layers;
    double canvas_utilization;
    char most_used_shape[32];
    int complexity_score;
    size_t memory_bytes;
} AnalyticsDashboard;

void analytics_get_dashboard(AnalyticsDashboard *dash);

#endif /* ANALYTICS_H */
