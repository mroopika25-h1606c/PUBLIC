#include "graphics.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

char canvas[CANVAS_HEIGHT][CANVAS_WIDTH];
int grid_view_enabled = 0;

void graphics_init_canvas(void) {
    for (int y = 0; y < CANVAS_HEIGHT; y++) {
        for (int x = 0; x < CANVAS_WIDTH; x++) {
            canvas[y][x] = '_';
        }
    }
}

void graphics_clear_canvas(void) {
    graphics_init_canvas();
}

void graphics_set_pixel(int x, int y, char draw_char) {
    if (x >= 0 && x < CANVAS_WIDTH && y >= 0 && y < CANVAS_HEIGHT) {
        canvas[y][x] = draw_char;
    }
}

char graphics_get_pixel(int x, int y) {
    if (x >= 0 && x < CANVAS_WIDTH && y >= 0 && y < CANVAS_HEIGHT) {
        return canvas[y][x];
    }
    return '_';
}

void graphics_draw_line(int x1, int y1, int x2, int y2, char draw_char) {
    int dx = abs(x2 - x1);
    int sx = x1 < x2 ? 1 : -1;
    int dy = -abs(y2 - y1);
    int sy = y1 < y2 ? 1 : -1;
    int err = dx + dy;
    int e2;

    while (1) {
        graphics_set_pixel(x1, y1, draw_char);
        if (x1 == x2 && y1 == y2) break;
        e2 = 2 * err;
        if (e2 >= dy) {
            err += dy;
            x1 += sx;
        }
        if (e2 <= dx) {
            err += dx;
            y1 += sy;
        }
    }
}

void graphics_draw_circle(int xc, int yc, int r, char draw_char, int fill) {
    if (r < 0) return;
    
    int x = 0;
    int y = r;
    int d = 3 - 2 * r;

    void draw_circle_spans(int xc, int yc, int x, int y, char draw_char, int fill) {
        if (fill) {
            /* Draw horizontal fill lines */
            graphics_draw_line(xc - x, yc + y, xc + x, yc + y, draw_char);
            graphics_draw_line(xc - x, yc - y, xc + x, yc - y, draw_char);
            graphics_draw_line(xc - y, yc + x, xc + y, yc + x, draw_char);
            graphics_draw_line(xc - y, yc - x, xc + y, yc - x, draw_char);
        } else {
            /* Draw boundary points */
            graphics_set_pixel(xc + x, yc + y, draw_char);
            graphics_set_pixel(xc - x, yc + y, draw_char);
            graphics_set_pixel(xc + x, yc - y, draw_char);
            graphics_set_pixel(xc - x, yc - y, draw_char);
            graphics_set_pixel(xc + y, yc + x, draw_char);
            graphics_set_pixel(xc - y, yc + x, draw_char);
            graphics_set_pixel(xc + y, yc - x, draw_char);
            graphics_set_pixel(xc - y, yc - x, draw_char);
        }
    }

    draw_circle_spans(xc, yc, x, y, draw_char, fill);
    while (y >= x) {
        x++;
        if (d > 0) {
            y--;
            d = d + 4 * (x - y) + 10;
        } else {
            d = d + 4 * x + 6;
        }
        draw_circle_spans(xc, yc, x, y, draw_char, fill);
    }
}

void graphics_draw_ellipse(int xc, int yc, int rx, int ry, char draw_char, int fill) {
    if (rx < 0 || ry < 0) return;
    if (rx == 0 && ry == 0) {
        graphics_set_pixel(xc, yc, draw_char);
        return;
    }

    int x = 0;
    int y = ry;

    long rx2 = (long)rx * rx;
    long ry2 = (long)ry * ry;
    long two_rx2 = 2 * rx2;
    long two_ry2 = 2 * ry2;

    long p;
    long px = 0;
    long py = two_rx2 * y;

    void draw_ellipse_spans(int xc, int yc, int x, int y, char draw_char, int fill) {
        if (fill) {
            graphics_draw_line(xc - x, yc + y, xc + x, yc + y, draw_char);
            graphics_draw_line(xc - x, yc - y, xc + x, yc - y, draw_char);
        } else {
            graphics_set_pixel(xc + x, yc + y, draw_char);
            graphics_set_pixel(xc - x, yc + y, draw_char);
            graphics_set_pixel(xc + x, yc - y, draw_char);
            graphics_set_pixel(xc - x, yc - y, draw_char);
        }
    }

    /* Region 1 */
    p = (long)(ry2 - (rx2 * ry) + (0.25 * rx2) + 0.5);
    while (px < py) {
        draw_ellipse_spans(xc, yc, x, y, draw_char, fill);
        x++;
        px += two_ry2;
        if (p < 0) {
            p += ry2 + px;
        } else {
            y--;
            py -= two_rx2;
            p += ry2 + px - py;
        }
    }

    /* Region 2 */
    p = (long)(ry2 * (x + 0.5) * (x + 0.5) + rx2 * (y - 1) * (y - 1) - rx2 * ry2 + 0.5);
    while (y >= 0) {
        draw_ellipse_spans(xc, yc, x, y, draw_char, fill);
        y--;
        py -= two_rx2;
        if (p > 0) {
            p += rx2 - py;
        } else {
            x++;
            px += two_ry2;
            p += rx2 - py + px;
        }
    }
}

void graphics_draw_triangle(int x1, int y1, int x2, int y2, int x3, int y3, char draw_char, int fill) {
    if (fill) {
        int xs[3] = {x1, x2, x3};
        int ys[3] = {y1, y2, y3};
        graphics_scanline_fill_polygon(xs, ys, 3, draw_char);
    } else {
        graphics_draw_line(x1, y1, x2, y2, draw_char);
        graphics_draw_line(x2, y2, x3, y3, draw_char);
        graphics_draw_line(x3, y3, x1, y1, draw_char);
    }
}

void graphics_draw_polygon(const int *xs, const int *ys, int num_points, char draw_char, int fill) {
    if (num_points < 3) return;
    
    if (fill) {
        graphics_scanline_fill_polygon(xs, ys, num_points, draw_char);
    } else {
        for (int i = 0; i < num_points; i++) {
            int next_i = (i + 1) % num_points;
            graphics_draw_line(xs[i], ys[i], xs[next_i], ys[next_i], draw_char);
        }
    }
}

void graphics_scanline_fill_polygon(const int *xs, const int *ys, int num_points, char draw_char) {
    if (num_points < 3) return;

    /* Find bounding box */
    int min_y = ys[0];
    int max_y = ys[0];
    for (int i = 1; i < num_points; i++) {
        if (ys[i] < min_y) min_y = ys[i];
        if (ys[i] > max_y) max_y = ys[i];
    }

    /* Clamp vertically to canvas boundaries */
    if (min_y < 0) min_y = 0;
    if (max_y >= CANVAS_HEIGHT) max_y = CANVAS_HEIGHT - 1;

    /* Scan each line */
    for (int y = min_y; y <= max_y; y++) {
        int intersections[256];
        int num_intersections = 0;

        for (int i = 0; i < num_points; i++) {
            int next_i = (i + 1) % num_points;
            int x1 = xs[i];
            int y1 = ys[i];
            int x2 = xs[next_i];
            int y2 = ys[next_i];

            /* Sort by y */
            if (y1 > y2) {
                int temp = x1; x1 = x2; x2 = temp;
                temp = y1; y1 = y2; y2 = temp;
            }

            /* Detect intersection of edge and scanline y */
            if ((y >= y1 && y < y2) || (y == max_y && y == y2)) {
                if (y2 != y1) {
                    double x_int = x1 + (double)(y - y1) * (x2 - x1) / (y2 - y1);
                    intersections[num_intersections++] = (int)(x_int + (x_int >= 0 ? 0.5 : -0.5));
                }
            }
        }

        /* Sort intersections in ascending order */
        for (int i = 0; i < num_intersections - 1; i++) {
            for (int j = 0; j < num_intersections - i - 1; j++) {
                if (intersections[j] > intersections[j + 1]) {
                    int temp = intersections[j];
                    intersections[j] = intersections[j + 1];
                    intersections[j + 1] = temp;
                }
            }
        }

        /* Fill scanline spans */
        for (int i = 0; i < num_intersections; i += 2) {
            if (i + 1 < num_intersections) {
                int x_start = intersections[i];
                int x_end = intersections[i + 1];
                
                if (x_start < 0) x_start = 0;
                if (x_end >= CANVAS_WIDTH) x_end = CANVAS_WIDTH - 1;
                
                for (int x = x_start; x <= x_end; x++) {
                    graphics_set_pixel(x, y, draw_char);
                }
            }
        }
    }
}
