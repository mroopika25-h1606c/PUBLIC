#define _CRT_SECURE_NO_WARNINGS
#include "object_manager.h"
#include "layer_manager.h"
#include "graphics.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* Global registry */
CanvasObject object_registry[MAX_OBJECTS];
int object_count = 0;
static int next_object_id = 1;

/* Selection Clipboard */
CanvasObject object_clipboard;
int clipboard_has_object = 0;

/* Selection State */
int selected_object_id = -1;

/* Undo/Redo Stacks */
typedef struct {
    CanvasObject registry[MAX_OBJECTS];
    int count;
    int selected_id;
} HistoryState;

static HistoryState undo_stack[MAX_UNDO_STATES];
static int undo_top = -1;

static HistoryState redo_stack[MAX_UNDO_STATES];
static int redo_top = -1;

void obj_history_save(void) {
    /* If undo stack is full, shift left */
    if (undo_top == MAX_UNDO_STATES - 1) {
        for (int i = 0; i < MAX_UNDO_STATES - 1; i++) {
            undo_stack[i] = undo_stack[i + 1];
        }
        undo_top--;
    }
    
    undo_top++;
    undo_stack[undo_top].count = object_count;
    undo_stack[undo_top].selected_id = selected_object_id;
    memcpy(undo_stack[undo_top].registry, object_registry, sizeof(CanvasObject) * object_count);
    
    /* Clear redo stack */
    redo_top = -1;
}

int obj_history_undo(void) {
    if (undo_top < 0) return 0; // nothing to undo
    
    /* Save current to redo stack */
    if (redo_top < MAX_UNDO_STATES - 1) {
        redo_top++;
        redo_stack[redo_top].count = object_count;
        redo_stack[redo_top].selected_id = selected_object_id;
        memcpy(redo_stack[redo_top].registry, object_registry, sizeof(CanvasObject) * object_count);
    }
    
    /* Restore from undo stack */
    object_count = undo_stack[undo_top].count;
    selected_object_id = undo_stack[undo_top].selected_id;
    memcpy(object_registry, undo_stack[undo_top].registry, sizeof(CanvasObject) * object_count);
    undo_top--;
    
    return 1;
}

int obj_history_redo(void) {
    if (redo_top < 0) return 0; // nothing to redo
    
    /* Save current to undo stack */
    if (undo_top < MAX_UNDO_STATES - 1) {
        undo_top++;
        undo_stack[undo_top].count = object_count;
        undo_stack[undo_top].selected_id = selected_object_id;
        memcpy(undo_stack[undo_top].registry, object_registry, sizeof(CanvasObject) * object_count);
    }
    
    /* Restore from redo stack */
    object_count = redo_stack[redo_top].count;
    selected_object_id = redo_stack[redo_top].selected_id;
    memcpy(object_registry, redo_stack[redo_top].registry, sizeof(CanvasObject) * object_count);
    redo_top--;
    
    return 1;
}

void obj_history_clear(void) {
    undo_top = -1;
    redo_top = -1;
}

/* Helper to initialize common fields */
static void init_common_fields(CanvasObject *obj, ShapeType type, const char *name_prefix, char draw_char, int layer) {
    obj->id = next_object_id++;
    obj->type = type;
    sprintf(obj->name, "%s #%d", name_prefix, obj->id);
    obj->creation_time = time(NULL);
    obj->layer = layer;
    obj->is_visible = 1;
    obj->is_locked = 0;
    obj->group_id = 0; // ungrouped
    obj->draw_char = draw_char;
    obj->is_filled = 0;
}

int obj_create_line(int x1, int y1, int x2, int y2, char draw_char, int layer) {
    if (object_count >= MAX_OBJECTS) return -1;
    
    obj_history_save();
    CanvasObject *obj = &object_registry[object_count++];
    init_common_fields(obj, SHAPE_LINE, "Line", draw_char, layer);
    obj->params.line.p1.x = x1;
    obj->params.line.p1.y = y1;
    obj->params.line.p2.x = x2;
    obj->params.line.p2.y = y2;
    
    return obj->id;
}

int obj_create_rectangle(int x, int y, int w, int h, char draw_char, int layer, int filled) {
    if (object_count >= MAX_OBJECTS) return -1;
    
    obj_history_save();
    CanvasObject *obj = &object_registry[object_count++];
    init_common_fields(obj, SHAPE_RECTANGLE, "Rect", draw_char, layer);
    obj->params.rect.top_left.x = x;
    obj->params.rect.top_left.y = y;
    obj->params.rect.width = w;
    obj->params.rect.height = h;
    obj->is_filled = filled;
    
    return obj->id;
}

int obj_create_circle(int xc, int yc, int r, char draw_char, int layer, int filled) {
    if (object_count >= MAX_OBJECTS) return -1;
    
    obj_history_save();
    CanvasObject *obj = &object_registry[object_count++];
    init_common_fields(obj, SHAPE_CIRCLE, "Circle", draw_char, layer);
    obj->params.circle.center.x = xc;
    obj->params.circle.center.y = yc;
    obj->params.circle.radius = r;
    obj->is_filled = filled;
    
    return obj->id;
}

int obj_create_triangle(int x1, int y1, int x2, int y2, int x3, int y3, char draw_char, int layer, int filled) {
    if (object_count >= MAX_OBJECTS) return -1;
    
    obj_history_save();
    CanvasObject *obj = &object_registry[object_count++];
    init_common_fields(obj, SHAPE_TRIANGLE, "Triangle", draw_char, layer);
    obj->params.triangle.v1.x = x1;
    obj->params.triangle.v1.y = y1;
    obj->params.triangle.v2.x = x2;
    obj->params.triangle.v2.y = y2;
    obj->params.triangle.v3.x = x3;
    obj->params.triangle.v3.y = y3;
    obj->is_filled = filled;
    
    return obj->id;
}

int obj_create_ellipse(int xc, int yc, int rx, int ry, char draw_char, int layer, int filled) {
    if (object_count >= MAX_OBJECTS) return -1;
    
    obj_history_save();
    CanvasObject *obj = &object_registry[object_count++];
    init_common_fields(obj, SHAPE_ELLIPSE, "Ellipse", draw_char, layer);
    obj->params.ellipse.center.x = xc;
    obj->params.ellipse.center.y = yc;
    obj->params.ellipse.rx = rx;
    obj->params.ellipse.ry = ry;
    obj->is_filled = filled;
    
    return obj->id;
}

int obj_create_polygon(const int *xs, const int *ys, int num_points, char draw_char, int layer, int filled) {
    if (object_count >= MAX_OBJECTS) return -1;
    if (num_points > MAX_POLY_POINTS) num_points = MAX_POLY_POINTS;
    
    obj_history_save();
    CanvasObject *obj = &object_registry[object_count++];
    init_common_fields(obj, SHAPE_POLYGON, "Polygon", draw_char, layer);
    obj->params.polygon.num_vertices = num_points;
    for (int i = 0; i < num_points; i++) {
        obj->params.polygon.vertices[i].x = xs[i];
        obj->params.polygon.vertices[i].y = ys[i];
    }
    obj->is_filled = filled;
    
    return obj->id;
}

int obj_delete(int id) {
    CanvasObject *obj = obj_find_by_id(id);
    if (!obj || obj->is_locked) return 0;
    
    obj_history_save();
    
    /* Find index */
    int idx = -1;
    for (int i = 0; i < object_count; i++) {
        if (object_registry[i].id == id) {
            idx = i;
            break;
        }
    }
    
    if (idx < 0) return 0;
    
    /* Shift left */
    for (int i = idx; i < object_count - 1; i++) {
        object_registry[i] = object_registry[i + 1];
    }
    object_count--;
    
    if (selected_object_id == id) {
        selected_object_id = -1;
    }
    
    return 1;
}

int obj_delete_multiple(const int *ids, int count) {
    obj_history_save();
    int deleted_any = 0;
    
    for (int i = 0; i < count; i++) {
        /* Deleting shift left dynamically shifts array. We delete by ID, finding the new idx each time. */
        deleted_any |= obj_delete(ids[i]);
    }
    return deleted_any;
}

void obj_clear_all(void) {
    obj_history_save();
    object_count = 0;
    selected_object_id = -1;
}

CanvasObject* obj_find_by_id(int id) {
    for (int i = 0; i < object_count; i++) {
        if (object_registry[i].id == id) {
            return &object_registry[i];
        }
    }
    return NULL;
}

int obj_find_all_in_group(int group_id, int *ids_out, int max_out) {
    if (group_id == 0) return 0;
    
    int c = 0;
    for (int i = 0; i < object_count; i++) {
        if (object_registry[i].group_id == group_id) {
            if (c < max_out) {
                ids_out[c++] = object_registry[i].id;
            }
        }
    }
    return c;
}

/* Transformations */
void obj_translate(CanvasObject *obj, int dx, int dy) {
    if (!obj || obj->is_locked) return;
    
    /* If object is grouped, translate all objects in group */
    if (obj->group_id != 0) {
        /* Prevent infinite loop by clearing group ID temporarily or tracking processed objects */
        int group_ids[100];
        int count = obj_find_all_in_group(obj->group_id, group_ids, 100);
        for (int i = 0; i < count; i++) {
            CanvasObject *group_obj = obj_find_by_id(group_ids[i]);
            if (group_obj && group_obj != obj && !group_obj->is_locked) {
                /* Translate coordinates directly without repeating grouping search */
                switch (group_obj->type) {
                    case SHAPE_LINE:
                        group_obj->params.line.p1.x += dx;
                        group_obj->params.line.p1.y += dy;
                        group_obj->params.line.p2.x += dx;
                        group_obj->params.line.p2.y += dy;
                        break;
                    case SHAPE_RECTANGLE:
                        group_obj->params.rect.top_left.x += dx;
                        group_obj->params.rect.top_left.y += dy;
                        break;
                    case SHAPE_CIRCLE:
                        group_obj->params.circle.center.x += dx;
                        group_obj->params.circle.center.y += dy;
                        break;
                    case SHAPE_TRIANGLE:
                        group_obj->params.triangle.v1.x += dx;
                        group_obj->params.triangle.v1.y += dy;
                        group_obj->params.triangle.v2.x += dx;
                        group_obj->params.triangle.v2.y += dy;
                        group_obj->params.triangle.v3.x += dx;
                        group_obj->params.triangle.v3.y += dy;
                        break;
                    case SHAPE_ELLIPSE:
                        group_obj->params.ellipse.center.x += dx;
                        group_obj->params.ellipse.center.y += dy;
                        break;
                    case SHAPE_POLYGON:
                        for (int k = 0; k < group_obj->params.polygon.num_vertices; k++) {
                            group_obj->params.polygon.vertices[k].x += dx;
                            group_obj->params.polygon.vertices[k].y += dy;
                        }
                        break;
                }
            }
        }
    }
    
    switch (obj->type) {
        case SHAPE_LINE:
            obj->params.line.p1.x += dx;
            obj->params.line.p1.y += dy;
            obj->params.line.p2.x += dx;
            obj->params.line.p2.y += dy;
            break;
        case SHAPE_RECTANGLE:
            obj->params.rect.top_left.x += dx;
            obj->params.rect.top_left.y += dy;
            break;
        case SHAPE_CIRCLE:
            obj->params.circle.center.x += dx;
            obj->params.circle.center.y += dy;
            break;
        case SHAPE_TRIANGLE:
            obj->params.triangle.v1.x += dx;
            obj->params.triangle.v1.y += dy;
            obj->params.triangle.v2.x += dx;
            obj->params.triangle.v2.y += dy;
            obj->params.triangle.v3.x += dx;
            obj->params.triangle.v3.y += dy;
            break;
        case SHAPE_ELLIPSE:
            obj->params.ellipse.center.x += dx;
            obj->params.ellipse.center.y += dy;
            break;
        case SHAPE_POLYGON:
            for (int i = 0; i < obj->params.polygon.num_vertices; i++) {
                obj->params.polygon.vertices[i].x += dx;
                obj->params.polygon.vertices[i].y += dy;
            }
            break;
    }
}

void obj_resize(CanvasObject *obj, int dp1, int dp2) {
    if (!obj || obj->is_locked) return;
    
    switch (obj->type) {
        case SHAPE_LINE:
            obj->params.line.p2.x += dp1;
            obj->params.line.p2.y += dp2;
            break;
        case SHAPE_RECTANGLE:
            obj->params.rect.width += dp1;
            obj->params.rect.height += dp2;
            if (obj->params.rect.width < 1) obj->params.rect.width = 1;
            if (obj->params.rect.height < 1) obj->params.rect.height = 1;
            break;
        case SHAPE_CIRCLE:
            obj->params.circle.radius += dp1;
            if (obj->params.circle.radius < 0) obj->params.circle.radius = 0;
            break;
        case SHAPE_TRIANGLE:
            /* Resize triangle by moving vertices slightly */
            obj->params.triangle.v2.x += dp1;
            obj->params.triangle.v2.y += dp2;
            obj->params.triangle.v3.x -= dp1;
            obj->params.triangle.v3.y += dp2;
            break;
        case SHAPE_ELLIPSE:
            obj->params.ellipse.rx += dp1;
            obj->params.ellipse.ry += dp2;
            if (obj->params.ellipse.rx < 0) obj->params.ellipse.rx = 0;
            if (obj->params.ellipse.ry < 0) obj->params.ellipse.ry = 0;
            break;
        case SHAPE_POLYGON:
            /* Shift points away from centroid */
            obj_scale(obj, 1.0 + (double)dp1 / 10.0);
            break;
    }
}

static void get_centroid(CanvasObject *obj, double *cx, double *cy) {
    switch (obj->type) {
        case SHAPE_LINE:
            *cx = (obj->params.line.p1.x + obj->params.line.p2.x) / 2.0;
            *cy = (obj->params.line.p1.y + obj->params.line.p2.y) / 2.0;
            break;
        case SHAPE_RECTANGLE:
            *cx = obj->params.rect.top_left.x + obj->params.rect.width / 2.0;
            *cy = obj->params.rect.top_left.y + obj->params.rect.height / 2.0;
            break;
        case SHAPE_CIRCLE:
            *cx = obj->params.circle.center.x;
            *cy = obj->params.circle.center.y;
            break;
        case SHAPE_TRIANGLE:
            *cx = (obj->params.triangle.v1.x + obj->params.triangle.v2.x + obj->params.triangle.v3.x) / 3.0;
            *cy = (obj->params.triangle.v1.y + obj->params.triangle.v2.y + obj->params.triangle.v3.y) / 3.0;
            break;
        case SHAPE_ELLIPSE:
            *cx = obj->params.ellipse.center.x;
            *cy = obj->params.ellipse.center.y;
            break;
        case SHAPE_POLYGON: {
            double sx = 0, sy = 0;
            int n = obj->params.polygon.num_vertices;
            for (int i = 0; i < n; i++) {
                sx += obj->params.polygon.vertices[i].x;
                sy += obj->params.polygon.vertices[i].y;
            }
            *cx = sx / n;
            *cy = sy / n;
            break;
        }
        default:
            *cx = 0;
            *cy = 0;
            break;
    }
}

void obj_scale(CanvasObject *obj, double factor) {
    if (!obj || obj->is_locked || factor <= 0.0) return;

    double cx = 0, cy = 0;
    get_centroid(obj, &cx, &cy);

    switch (obj->type) {
        case SHAPE_LINE: {
            double dx1 = obj->params.line.p1.x - cx;
            double dy1 = obj->params.line.p1.y - cy;
            double dx2 = obj->params.line.p2.x - cx;
            double dy2 = obj->params.line.p2.y - cy;
            obj->params.line.p1.x = (int)(cx + dx1 * factor + (dx1 >= 0 ? 0.5 : -0.5));
            obj->params.line.p1.y = (int)(cy + dy1 * factor + (dy1 >= 0 ? 0.5 : -0.5));
            obj->params.line.p2.x = (int)(cx + dx2 * factor + (dx2 >= 0 ? 0.5 : -0.5));
            obj->params.line.p2.y = (int)(cy + dy2 * factor + (dy2 >= 0 ? 0.5 : -0.5));
            break;
        }
        case SHAPE_RECTANGLE: {
            double dx = obj->params.rect.top_left.x - cx;
            double dy = obj->params.rect.top_left.y - cy;
            obj->params.rect.top_left.x = (int)(cx + dx * factor + (dx >= 0 ? 0.5 : -0.5));
            obj->params.rect.top_left.y = (int)(cy + dy * factor + (dy >= 0 ? 0.5 : -0.5));
            obj->params.rect.width = (int)(obj->params.rect.width * factor + 0.5);
            obj->params.rect.height = (int)(obj->params.rect.height * factor + 0.5);
            if (obj->params.rect.width < 1) obj->params.rect.width = 1;
            if (obj->params.rect.height < 1) obj->params.rect.height = 1;
            break;
        }
        case SHAPE_CIRCLE:
            obj->params.circle.radius = (int)(obj->params.circle.radius * factor + 0.5);
            if (obj->params.circle.radius < 0) obj->params.circle.radius = 0;
            break;
        case SHAPE_ELLIPSE:
            obj->params.ellipse.rx = (int)(obj->params.ellipse.rx * factor + 0.5);
            obj->params.ellipse.ry = (int)(obj->params.ellipse.ry * factor + 0.5);
            if (obj->params.ellipse.rx < 0) obj->params.ellipse.rx = 0;
            if (obj->params.ellipse.ry < 0) obj->params.ellipse.ry = 0;
            break;
        case SHAPE_TRIANGLE: {
            double dx1 = obj->params.triangle.v1.x - cx;
            double dy1 = obj->params.triangle.v1.y - cy;
            double dx2 = obj->params.triangle.v2.x - cx;
            double dy2 = obj->params.triangle.v2.y - cy;
            double dx3 = obj->params.triangle.v3.x - cx;
            double dy3 = obj->params.triangle.v3.y - cy;
            obj->params.triangle.v1.x = (int)(cx + dx1 * factor + (dx1 >= 0 ? 0.5 : -0.5));
            obj->params.triangle.v1.y = (int)(cy + dy1 * factor + (dy1 >= 0 ? 0.5 : -0.5));
            obj->params.triangle.v2.x = (int)(cx + dx2 * factor + (dx2 >= 0 ? 0.5 : -0.5));
            obj->params.triangle.v2.y = (int)(cy + dy2 * factor + (dy2 >= 0 ? 0.5 : -0.5));
            obj->params.triangle.v3.x = (int)(cx + dx3 * factor + (dx3 >= 0 ? 0.5 : -0.5));
            obj->params.triangle.v3.y = (int)(cy + dy3 * factor + (dy3 >= 0 ? 0.5 : -0.5));
            break;
        }
        case SHAPE_POLYGON: {
            int n = obj->params.polygon.num_vertices;
            for (int i = 0; i < n; i++) {
                double dx = obj->params.polygon.vertices[i].x - cx;
                double dy = obj->params.polygon.vertices[i].y - cy;
                obj->params.polygon.vertices[i].x = (int)(cx + dx * factor + (dx >= 0 ? 0.5 : -0.5));
                obj->params.polygon.vertices[i].y = (int)(cy + dy * factor + (dy >= 0 ? 0.5 : -0.5));
            }
            break;
        }
    }
}

void obj_rotate_triangle(CanvasObject *obj, double angle_deg) {
    if (!obj || obj->is_locked || obj->type != SHAPE_TRIANGLE) return;
    
    double cx = 0, cy = 0;
    get_centroid(obj, &cx, &cy);
    
    double rad = angle_deg * 3.141592653589793 / 180.0;
    double cos_a = cos(rad);
    double sin_a = sin(rad);
    
    void rotate_pt(ObjPoint *pt, double cx, double cy, double cos_a, double sin_a) {
        double dx = pt->x - cx;
        double dy = pt->y - cy;
        pt->x = (int)(cx + dx * cos_a - dy * sin_a + 0.5);
        pt->y = (int)(cy + dx * sin_a + dy * cos_a + 0.5);
    }
    
    rotate_pt(&obj->params.triangle.v1, cx, cy, cos_a, sin_a);
    rotate_pt(&obj->params.triangle.v2, cx, cy, cos_a, sin_a);
    rotate_pt(&obj->params.triangle.v3, cx, cy, cos_a, sin_a);
}

void obj_mirror_horizontal(CanvasObject *obj) {
    if (!obj || obj->is_locked) return;
    
    /* Horizontal mirroring flips around the center of the canvas */
    int mid_x = CANVAS_WIDTH / 2; // e.g. 40
    
    switch (obj->type) {
        case SHAPE_LINE:
            obj->params.line.p1.x = (2 * mid_x) - obj->params.line.p1.x;
            obj->params.line.p2.x = (2 * mid_x) - obj->params.line.p2.x;
            break;
        case SHAPE_RECTANGLE:
            obj->params.rect.top_left.x = (2 * mid_x) - (obj->params.rect.top_left.x + obj->params.rect.width);
            break;
        case SHAPE_CIRCLE:
            obj->params.circle.center.x = (2 * mid_x) - obj->params.circle.center.x;
            break;
        case SHAPE_TRIANGLE:
            obj->params.triangle.v1.x = (2 * mid_x) - obj->params.triangle.v1.x;
            obj->params.triangle.v2.x = (2 * mid_x) - obj->params.triangle.v2.x;
            obj->params.triangle.v3.x = (2 * mid_x) - obj->params.triangle.v3.x;
            break;
        case SHAPE_ELLIPSE:
            obj->params.ellipse.center.x = (2 * mid_x) - obj->params.ellipse.center.x;
            break;
        case SHAPE_POLYGON:
            for (int i = 0; i < obj->params.polygon.num_vertices; i++) {
                obj->params.polygon.vertices[i].x = (2 * mid_x) - obj->params.polygon.vertices[i].x;
            }
            break;
    }
}

void obj_mirror_vertical(CanvasObject *obj) {
    if (!obj || obj->is_locked) return;
    
    /* Vertical mirroring flips around the center of the canvas */
    int mid_y = CANVAS_HEIGHT / 2; // e.g. 12
    
    switch (obj->type) {
        case SHAPE_LINE:
            obj->params.line.p1.y = (2 * mid_y) - obj->params.line.p1.y;
            obj->params.line.p2.y = (2 * mid_y) - obj->params.line.p2.y;
            break;
        case SHAPE_RECTANGLE:
            obj->params.rect.top_left.y = (2 * mid_y) - (obj->params.rect.top_left.y + obj->params.rect.height);
            break;
        case SHAPE_CIRCLE:
            obj->params.circle.center.y = (2 * mid_y) - obj->params.circle.center.y;
            break;
        case SHAPE_TRIANGLE:
            obj->params.triangle.v1.y = (2 * mid_y) - obj->params.triangle.v1.y;
            obj->params.triangle.v2.y = (2 * mid_y) - obj->params.triangle.v2.y;
            obj->params.triangle.v3.y = (2 * mid_y) - obj->params.triangle.v3.y;
            break;
        case SHAPE_ELLIPSE:
            obj->params.ellipse.center.y = (2 * mid_y) - obj->params.ellipse.center.y;
            break;
        case SHAPE_POLYGON:
            for (int i = 0; i < obj->params.polygon.num_vertices; i++) {
                obj->params.polygon.vertices[i].y = (2 * mid_y) - obj->params.polygon.vertices[i].y;
            }
            break;
    }
}

/* Editor Tools */
int obj_copy(int id) {
    CanvasObject *obj = obj_find_by_id(id);
    if (!obj) return 0;
    
    object_clipboard = *obj;
    clipboard_has_object = 1;
    return 1;
}

int obj_paste(int layer) {
    if (!clipboard_has_object) return -1;
    if (object_count >= MAX_OBJECTS) return -1;
    
    obj_history_save();
    
    CanvasObject *new_obj = &object_registry[object_count++];
    *new_obj = object_clipboard;
    
    /* Reassign ID, creation time, layer, group */
    new_obj->id = next_object_id++;
    new_obj->creation_time = time(NULL);
    new_obj->layer = layer;
    new_obj->is_locked = 0;
    new_obj->group_id = 0;
    sprintf(new_obj->name, "%s (Copy)", object_clipboard.name);
    
    /* Translate slightly to indicate paste */
    obj_translate(new_obj, 2, 1);
    
    selected_object_id = new_obj->id;
    return new_obj->id;
}

int obj_duplicate(int id) {
    if (obj_copy(id)) {
        CanvasObject *orig = obj_find_by_id(id);
        if (orig) {
            return obj_paste(orig->layer);
        }
    }
    return -1;
}

int obj_group(const int *ids, int count) {
    if (count <= 1) return 0;
    
    obj_history_save();
    
    /* Find a new group id */
    int new_group_id = 1;
    for (int i = 0; i < object_count; i++) {
        if (object_registry[i].group_id >= new_group_id) {
            new_group_id = object_registry[i].group_id + 1;
        }
    }
    
    int grouped_count = 0;
    for (int i = 0; i < count; i++) {
        CanvasObject *obj = obj_find_by_id(ids[i]);
        if (obj && !obj->is_locked) {
            obj->group_id = new_group_id;
            grouped_count++;
        }
    }
    
    return grouped_count;
}

int obj_ungroup(int group_id) {
    if (group_id == 0) return 0;
    
    obj_history_save();
    
    int ungrouped_count = 0;
    for (int i = 0; i < object_count; i++) {
        if (object_registry[i].group_id == group_id) {
            object_registry[i].group_id = 0;
            ungrouped_count++;
        }
    }
    return ungrouped_count;
}

/* Rendering Compositor */
void compositor_render(void) {
    graphics_clear_canvas();
    
    /* Iterate layers by render order (ascending) */
    int active_layers[MAX_LAYERS];
    int layer_count = layer_get_render_list(active_layers);
    
    for (int l = 0; l < layer_count; l++) {
        int layer_id = active_layers[l];
        
        /* Check if layer is visible */
        if (!layer_is_visible(layer_id)) continue;
        
        /* Render all visible objects in this layer */
        for (int i = 0; i < object_count; i++) {
            CanvasObject *obj = &object_registry[i];
            if (obj->layer == layer_id && obj->is_visible) {
                char ch = obj->draw_char;
                switch (obj->type) {
                    case SHAPE_LINE:
                        graphics_draw_line(obj->params.line.p1.x, obj->params.line.p1.y,
                                           obj->params.line.p2.x, obj->params.line.p2.y, ch);
                        break;
                    case SHAPE_RECTANGLE: {
                        int rx = obj->params.rect.top_left.x;
                        int ry = obj->params.rect.top_left.y;
                        int rw = obj->params.rect.width;
                        int rh = obj->params.rect.height;
                        if (obj->is_filled) {
                            for (int y = ry; y < ry + rh; y++) {
                                for (int x = rx; x < rx + rw; x++) {
                                    graphics_set_pixel(x, y, ch);
                                }
                            }
                        } else {
                            graphics_draw_line(rx, ry, rx + rw - 1, ry, ch);
                            graphics_draw_line(rx, ry + rh - 1, rx + rw - 1, ry + rh - 1, ch);
                            graphics_draw_line(rx, ry, rx, ry + rh - 1, ch);
                            graphics_draw_line(rx + rw - 1, ry, rx + rw - 1, ry + rh - 1, ch);
                        }
                        break;
                    }
                    case SHAPE_CIRCLE:
                        graphics_draw_circle(obj->params.circle.center.x, obj->params.circle.center.y,
                                             obj->params.circle.radius, ch, obj->is_filled);
                        break;
                    case SHAPE_TRIANGLE:
                        graphics_draw_triangle(obj->params.triangle.v1.x, obj->params.triangle.v1.y,
                                               obj->params.triangle.v2.x, obj->params.triangle.v2.y,
                                               obj->params.triangle.v3.x, obj->params.triangle.v3.y,
                                               ch, obj->is_filled);
                        break;
                    case SHAPE_ELLIPSE:
                        graphics_draw_ellipse(obj->params.ellipse.center.x, obj->params.ellipse.center.y,
                                              obj->params.ellipse.rx, obj->params.ellipse.ry,
                                              ch, obj->is_filled);
                        break;
                    case SHAPE_POLYGON: {
                        int xs[MAX_POLY_POINTS];
                        int ys[MAX_POLY_POINTS];
                        int n = obj->params.polygon.num_vertices;
                        for (int k = 0; k < n; k++) {
                            xs[k] = obj->params.polygon.vertices[k].x;
                            ys[k] = obj->params.polygon.vertices[k].y;
                        }
                        graphics_draw_polygon(xs, ys, n, ch, obj->is_filled);
                        break;
                    }
                }
            }
        }
    }
}
